I finished the extra credit portion.

Alice sent "Bob, I love you. mailman:Yibo Xu" that message to Bob, she also created a sign for it.
Bob verify this message is true, and decrypt that to get the message "Bob, I love you. mailman:Yibo Xu"


The output I got you can find in my output.txt.