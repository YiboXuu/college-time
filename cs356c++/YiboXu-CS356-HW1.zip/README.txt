you can test my file by running this.



mkdir build
cd build
cmake ..
make
./hw1 B SB1.txt SB1.txt keyfile.txt D

					must with .txt
