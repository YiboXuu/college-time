

1.   javac -cp .:/usr/share/java/mysql-connector-java.jar Lab5.java GUI.java Library.java


2.   java -cp .:/usr/share/java/mysql-connector-java.jar Lab5





then we can see the secreen.