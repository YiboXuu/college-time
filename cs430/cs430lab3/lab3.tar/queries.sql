
select *
from Library
ORDER BY Name;

select*
from LocatedAt
ORDER BY ISBN;


SELECT Book.Title, SO1.TotalCopies, SO1.LibraryName
FROM Book, LocatedAt SO1, LocatedAt SO2
WHERE Book.ISBN = SO1.ISBN and
    SO1.ISBN = SO2.ISBN and
    SO1.LibraryName != SO2.LibraryName
ORDER BY Book.Title;

select LibraryName,count(ISBN) as NumberOfTitles
FROM LocatedAt
GROUP BY LibraryName
ORDER BY LibraryName;