

1.   javac -cp .:/usr/share/java/mysql-connector-java.jar Lab4.java


2.   java -cp .:/usr/share/java/mysql-connector-java.jar Lab4





then we can get the output.